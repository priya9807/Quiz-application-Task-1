//Array of questions gruoped by category (50 questions each)
const questions = [
  {
    category: "python",
    questions: [
      {
        question: "What is Python?",
        options: ["A programming language", "A type of snake", "A web browser", "An operating system"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is the correct way to declare a variable in Python?",
        options: ["var x = 10;", "int x = 10;", "x = 10", "let x = 10;"],
        correctAnswer: 2,
      },
      {
        question: "How do you write a comment in Python?",
        options: ["// This is a comment", "/* This is a comment */", "# This is a comment", "<!-- This is a comment -->"],
        correctAnswer: 2,
      },
      {
        question: "What is the output of 'print(10 + 5)'?",
        options: ["10 + 5", "15", "105", "Error"],
        correctAnswer: 1,
      },
      {
        question: "Which keyword is used to define a function in Python?",
        options: ["function", "def", "func", "define"],
        correctAnswer: 1,
      },
      {
        question: "What is the file extension for a Python file?",
        options: [".py", ".pyt", ".p", ".pyth"],
        correctAnswer: 0,
      },
      {
        question: "How do you create a list in Python?",
        options: ["[]", "{}", "()", "list()"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct way to get the length of a list named 'my_list'?",
        options: ["my_list.length()", "len(my_list)", "my_list.size()", "count(my_list)"],
        correctAnswer: 1,
      },
      {
        question: "Which of the following is not a data type in Python?",
        options: ["list", "tuple", "string", "array"],
        correctAnswer: 3,
      },
      {
        question: "How do you start a for loop in Python?",
        options: ["for i in range(5):", "for (i = 0; i < 5; i++)", "foreach (i in list)", "loop i from 0 to 5"],
        correctAnswer: 0,
      },
      {
        question: "What is the result of 'print(type(10))'?",
        options: ["<class 'int'>", "<class 'str'>", "<class 'float'>", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you read a line from a file in Python?",
        options: ["read_line()", "file.readline()", "getline()", "file.read_line()"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'if __name__ == '__main__': ' block?",
        options: ["To define a main function", "To run code only when the script is executed directly", "To import modules", "To handle errors"],
        correctAnswer: 1,
      },
      {
        question: "How do you import a module named 'math'?",
        options: ["import 'math'", "import math", "include math", "use math"],
        correctAnswer: 1,
      },
      {
        question: "What does the 'pass' statement do in Python?",
        options: ["It ends the program", "It is a null operation; nothing happens when it executes", "It skips the current loop iteration", "It returns a value from a function"],
        correctAnswer: 1,
      },
      {
        question: "What is a dictionary in Python?",
        options: ["An ordered collection of items", "A collection of key-value pairs", "A list of numbers", "A type of comment"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the value of a key 'name' from a dictionary named 'person'?",
        options: ["person.get('name')", "person['name']", "Both A and B", "person('name')"],
        correctAnswer: 2,
      },
      {
        question: "Which of the following is used to handle exceptions in Python?",
        options: ["try...catch", "try...except", "begin...rescue", "error...handle"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'self' keyword in a class?",
        options: ["It refers to the current instance of the class", "It is a reserved keyword", "It is used for inheritance", "It is a global variable"],
        correctAnswer: 0,
      },
      {
        question: "How do you create a class named 'Car' in Python?",
        options: ["class Car:", "define class Car:", "create class Car", "class Car()"],
        correctAnswer: 0,
      },
      {
        question: "What is a tuple in Python?",
        options: ["An ordered, mutable collection", "An unordered, mutable collection", "An ordered, immutable collection", "An unordered, immutable collection"],
        correctAnswer: 2,
      },
      {
        question: "How do you create a new line in a string?",
        options: ["\\n", "\\r", "\\t", "\\l"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'print('Hello' + 'World')'?",
        options: ["HelloWorld", "Hello World", "Hello+World", "Error"],
        correctAnswer: 0,
      },
      {
        question: "Which operator is used for exponentiation?",
        options: ["^", "**", "pow()", "//"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'return' statement in a function?",
        options: ["To print a value", "To end the function", "To return a value from the function", "To define a variable"],
        correctAnswer: 2,
      },
      {
        question: "What is the correct syntax for a while loop?",
        options: ["while (condition)", "while condition:", "while condition do", "loop while condition"],
        correctAnswer: 1,
      },
      {
        question: "How do you check if a value is in a list 'my_list'?",
        options: ["'value' in my_list", "my_list.contains('value')", "my_list.has('value')", "contains(my_list, 'value')"],
        correctAnswer: 0,
      },
      {
        question: "What is a generator in Python?",
        options: ["A function that returns a value", "A function that can be iterated over", "A type of class", "A built-in data type"],
        correctAnswer: 1,
      },
      {
        question: "Which module is used for working with regular expressions?",
        options: ["re", "regex", "regexp", "patterns"],
        correctAnswer: 0,
      },
      {
        question: "What is the difference between 'is' and '=='?",
        options: ["'is' checks for value equality, '==' checks for identity", "'is' checks for identity, '==' checks for value equality", "They are the same", "None of the above"],
        correctAnswer: 1,
      },
      {
        question: "How do you remove an item from a list by its value?",
        options: ["my_list.delete('value')", "del my_list['value']", "my_list.remove('value')", "pop(my_list, 'value')"],
        correctAnswer: 2,
      },
      {
        question: "What is a lambda function?",
        options: ["A normal function", "An anonymous function", "A function that returns a list", "A function that takes no arguments"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'print(len('Python'))'?",
        options: ["6", "5", "7", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you convert a string to an integer?",
        options: ["int('10')", "str_to_int('10')", "to_int('10')", "integer('10')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is an immutable data type?",
        options: ["list", "dict", "set", "tuple"],
        correctAnswer: 3,
      },
      {
        question: "How do you open a file in write mode?",
        options: ["open('file.txt', 'r')", "open('file.txt', 'w')", "open('file.txt', 'a')", "open('file.txt', 'x')"],
        correctAnswer: 1,
      },
      {
        question: "What is a class method?",
        options: ["A method that is associated with an instance of a class", "A method that is associated with the class itself, not an instance", "A method that takes no arguments", "A method that is a static method"],
        correctAnswer: 1.
      },
      {
        question: "Which built-in function is used to get user input?",
        options: ["get_input()", "input()", "read_input()", "user_input()"],
        correctAnswer: 1,
      },
      {
        question: "What is the correct way to create an empty dictionary?",
        options: ["{}", "dict()", "Both A and B", "[]"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'yield' keyword?",
        options: ["To return a value from a function", "To create a generator", "To define a class", "To handle exceptions"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the current working directory?",
        options: ["os.getcwd()", "os.get_cwd()", "os.currentdir()", "os.path.getcwd()"],
        correctAnswer: 0,
      },
      {
        question: "What is a module in Python?",
        options: ["A single function", "A single class", "A file containing Python code", "A variable"],
        correctAnswer: 2,
      },
      {
        question: "What is the output of 'print(3 * 'A')'?",
        options: ["AAA", "3A", "A3", "Error"],
        correctAnswer: 0,
      },
      {
        question: "Which data structure is used to implement a stack?",
        options: ["list", "tuple", "dict", "set"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'pop()' method do on a list?",
        options: ["Removes an item from the beginning of the list", "Removes an item from the end of the list", "Adds an item to the end of the list", "Reverses the list"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the type of a variable 'x'?",
        options: ["type(x)", "typeof(x)", "get_type(x)", "x.type()"],
        correctAnswer: 0,
      },
      {
        question: "What is a set in Python?",
        options: ["An ordered collection of unique items", "An unordered collection of unique items", "An ordered collection of items", "An unordered collection of items"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'sys' module?",
        options: ["To work with the operating system", "To work with system-specific parameters and functions", "To handle files", "To work with dates and times"],
        correctAnswer: 1,
      },
      {
        question: "How do you sort a list 'my_list' in place?",
        options: ["my_list.sort()", "sorted(my_list)", "my_list.sorted()", "sort(my_list)"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'print(5 // 2)'?",
        options: ["2.5", "2", "3", "Error"],
        correctAnswer: 1,
      }
    ]
  },
  {
    category: "javascript",
    questions: [
      {
        question: "What does HTML stand for?",
        options: ["Hyper Tool Multi Language", "Hyper Text Pre Processor", "Hyper Text Markup Language", "Hyper Text Multiple Language"],
        correctAnswer: 2,
      },
      {
        question: "Which of the following is a correct way to declare a variable in JavaScript?",
        options: ["var x = 10;", "variable x = 10;", "int x = 10;", "let 10 = x;"],
        correctAnswer: 0,
      },
      {
        question: "How do you write a comment in JavaScript?",
        options: ["// This is a comment", "# this is a comment", "/* This is a comment */", "<!-- This is a comment -->"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'console.log(10 + 5)'?",
        options: ["10 + 5", "15", "105", "Error"],
        correctAnswer: 1,
      },
      {
        question: "Which keyword is used to define a function in JavaScript?",
        options: ["function", "def", "func", "define"],
        correctAnswer: 0,
      },
      {
        question: "What is the file extension for a JavaScript file?",
        options: [".js", ".jsc", ".script", ".java"],
        correctAnswer: 0,
      },
      {
        question: "How do you create an array in JavaScript?",
        options: ["[]", "{}", "()", "array()"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct way to get the length of an array named 'myArray'?",
        options: ["myArray.length()", "myArray.length", "len(myArray)", "myArray.size()"],
        correctAnswer: 1,
      },
      {
        question: "Which of the following is not a data type in JavaScript?",
        options: ["string", "number", "boolean", "float"],
        correctAnswer: 3,
      },
      {
        question: "How do you start a for loop in JavaScript?",
        options: ["for (i = 0; i < 5; i++)", "for i in range(5)", "foreach (i in list)", "loop i from 0 to 5"],
        correctAnswer: 0,
      },
      {
        question: "What is the result of 'console.log(typeof 10)'?",
        options: ["'number'", "'string'", "'integer'", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you get a DOM element by its ID?",
        options: ["document.getElementById()", "document.get('element')", "getElementByID()", "document.find('id')"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'use strict' directive?",
        options: ["To prevent errors", "To enable new JavaScript features", "To enforce a stricter parsing and error handling", "To make code faster"],
        correctAnswer: 2,
      },
      {
        question: "How do you include an external JavaScript file?",
        options: ["<script src='file.js'>", "<script href='file.js'>", "<link rel='script' href='file.js'>", "<js src='file.js'>"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'break' statement do in a loop?",
        options: ["It ends the program", "It exits the loop immediately", "It skips the current loop iteration", "It returns a value from a function"],
        correctAnswer: 1,
      },
      {
        question: "What is an object in JavaScript?",
        options: ["An ordered collection of items", "A collection of key-value pairs", "A list of numbers", "A type of comment"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the value of a key 'name' from an object named 'person'?",
        options: ["person.name", "person['name']", "Both A and B", "person('name')"],
        correctAnswer: 2,
      },
      {
        question: "Which of the following is used to handle exceptions in JavaScript?",
        options: ["try...catch", "try...except", "begin...rescue", "error...handle"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'this' keyword?",
        options: ["It refers to the current function", "It refers to the owner of the function", "It is a reserved keyword", "It is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a class named 'Car' in JavaScript?",
        options: ["class Car {}", "define class Car {}", "create class Car {}", "class Car()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'const' variable?",
        options: ["A variable that can be reassigned", "A variable that cannot be reassigned", "A variable that is always a number", "A variable that is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a new line in a string?",
        options: ["\\n", "\\r", "\\t", "\\l"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'console.log('Hello' + 'World')'?",
        options: ["HelloWorld", "Hello World", "Hello+World", "Error"],
        correctAnswer: 0,
      },
      {
        question: "Which operator is used for exponentiation?",
        options: ["^", "**", "pow()", "//"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'return' statement in a function?",
        options: ["To print a value", "To end the function", "To return a value from the function", "To define a variable"],
        correctAnswer: 2,
      },
      {
        question: "What is the correct syntax for a while loop?",
        options: ["while (condition)", "while (condition) {}", "while condition {}", "loop while condition"],
        correctAnswer: 1,
      },
      {
        question: "How do you check if a value is in an array 'myArray'?",
        options: ["myArray.includes('value')", "myArray.contains('value')", "myArray.has('value')", "includes(myArray, 'value')"],
        correctAnswer: 0,
      },
      {
        question: "What is a callback function?",
        options: ["A function that is called by the user", "A function that is passed as an argument to another function", "A function that returns a value", "A function that takes no arguments"],
        correctAnswer: 1,
      },
      {
        question: "Which method is used to add an element to the end of an array?",
        options: ["push()", "add()", "append()", "insert()"],
        correctAnswer: 0,
      },
      {
        question: "What is the difference between '==' and '==='?",
        options: ["'==' checks for value equality, '===' checks for both value and type equality", "'==' checks for both value and type equality, '===' checks for value equality", "They are the same", "None of the above"],
        correctAnswer: 0,
      },
      {
        question: "How do you remove the last element from an array?",
        options: ["pop()", "remove()", "delete()", "splice()"],
        correctAnswer: 0,
      },
      {
        question: "What is a promise in JavaScript?",
        options: ["A special type of function", "An object representing the eventual completion or failure of an asynchronous operation", "A type of variable", "A way to handle errors"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'console.log('JavaScript'.length)'?",
        options: ["10", "9", "11", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you convert a string to a number?",
        options: ["Number('10')", "str_to_num('10')", "to_number('10')", "integer('10')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is a primitive data type?",
        options: ["object", "array", "function", "symbol"],
        correctAnswer: 3,
      },
      {
        question: "How do you get the current date and time?",
        options: ["new Date()", "getDate()", "currentDate()", "Date.now()"],
        correctAnswer: 0,
      },
      {
        question: "What is a static method in a class?",
        options: ["A method that is associated with an instance of a class", "A method that is associated with the class itself, not an instance", "A method that takes no arguments", "A method that is a private method"],
        correctAnswer: 1,
      },
      {
        question: "Which built-in function is used to get user input from a pop-up box?",
        options: ["prompt()", "input()", "read()", "user_input()"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct way to create an empty object?",
        options: ["{}", "new Object()", "Both A and B", "[]"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'async' and 'await' keywords?",
        options: ["To define a new type of variable", "To make asynchronous code easier to write and read", "To handle errors", "To create a loop"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the first element of an array?",
        options: ["myArray[0]", "myArray.first()", "myArray.get(0)", "myArray.pop(0)"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'document' object?",
        options: ["To work with the web browser's history", "To work with the HTML document and its content", "To work with the window", "To work with dates and times"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'console.log(3 * 'A')'?",
        options: ["AAA", "3A", "NaN", "Error"],
        correctAnswer: 2,
      },
      {
        question: "Which data structure is used to implement a queue?",
        options: ["array", "object", "map", "set"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'shift()' method do on an array?",
        options: ["Removes an item from the beginning of the array", "Removes an item from the end of the array", "Adds an item to the end of the array", "Reverses the array"],
        correctAnswer: 0,
      },
      {
        question: "How do you get the type of a variable 'x'?",
        options: ["typeof x", "type(x)", "get_type(x)", "x.type()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'Set' in JavaScript?",
        options: ["An ordered collection of unique items", "An unordered collection of unique items", "An ordered collection of items", "An unordered collection of items"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'window' object?",
        options: ["To work with the HTML document", "To represent the browser window", "To handle files", "To work with dates and times"],
        correctAnswer: 1,
      },
      {
        question: "How do you sort an array 'myArray' in place?",
        options: ["myArray.sort()", "sorted(myArray)", "myArray.sorted()", "sort(myArray)"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'console.log(10 / 2)'?",
        options: ["5", "5.0", "5.5", "Error"],
        correctAnswer: 0,
      }
    ]
  },
  {
    category: "c++",
    questions: [
      {
        question: "What does C++ stand for?",
        options: ["C Plus", "C with Classes", "C Programming Language", "C++ is not an acronym"],
        correctAnswer: 1
      },
      {
        question: "Which of the following is a correct way to declare an integer variable in C++?",
        options: ["var x = 10;", "int x = 10;", "let x = 10;", "x = 10;"],
        correctAnswer: 1,
      },
      {
        question: "How do you write a single-line comment in C++?",
        options: ["// This is a comment", "# this is a comment", "/* This is a comment */", "<!-- This is a comment -->"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'cout << 10 + 5;'?",
        options: ["10 + 5", "15", "105", "Error"],
        correctAnswer: 1,
      },
      {
        question: "Which keyword is used to define a function in C++?",
        options: ["function", "def", "func", "The return type, followed by the function name"],
        correctAnswer: 3,
      },
      {
        question: "What is the file extension for a C++ source file?",
        options: [".cpp", ".c++", ".h", ".ccp"],
        correctAnswer: 0,
      },
      {
        question: "How do you include a header file named 'iostream'?",
        options: ["include 'iostream'", "#include <iostream>", "import iostream", "using iostream;"],
        correctAnswer: 1,
      },
      {
        question: "What is the correct way to get the size of an array named 'myArray'?",
        options: ["myArray.length", "size(myArray)", "sizeof(myArray) / sizeof(myArray[0])", "myArray.size()"],
        correctAnswer: 2,
      },
      {
        question: "Which of the following is a primitive data type in C++?",
        options: ["string", "vector", "int", "map"],
        correctAnswer: 2,
      },
      {
        question: "How do you start a for loop in C++?",
        options: ["for (i = 0; i < 5; i++)", "for i in range(5)", "foreach (i in list)", "loop i from 0 to 5"],
        correctAnswer: 0,
      },
      {
        question: "What is the result of 'cout << typeid(10).name();'?",
        options: ["int", "i", "number", "Error"],
        correctAnswer: 1,
      },
      {
        question: "How do you read a line of text from the user in C++?",
        options: ["cin >> my_string;", "getline(cin, my_string);", "input()", "read_line();"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'main' function?",
        options: ["To define a class", "It is the entry point of the program", "To include header files", "To handle errors"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a pointer to an integer variable 'x'?",
        options: ["int* ptr = x;", "int* ptr = &x;", "int ptr = &x;", "pointer<int> ptr = x;"],
        correctAnswer: 1,
      },
      {
        question: "What does the 'break' statement do in a loop?",
        options: ["It ends the program", "It exits the loop immediately", "It skips the current loop iteration", "It returns a value from a function"],
        correctAnswer: 1,
      },
      {
        question: "What is an 'object' in C++?",
        options: ["An ordered collection of items", "An instance of a class", "A list of numbers", "A type of comment"],
        correctAnswer: 1,
      },
      {
        question: "How do you access a public member 'name' from an object 'person'?",
        options: ["person.name", "person->name", "Both A and B", "person('name')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is used to handle exceptions in C++?",
        options: ["try...catch", "try...except", "try...throw...catch", "error...handle"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'this' pointer?",
        options: ["It refers to the current function", "It refers to the object the member function is called on", "It is a reserved keyword", "It is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a class named 'Car' in C++?",
        options: ["class Car {}", "define class Car {}", "create class Car {}", "class Car()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'const' variable?",
        options: ["A variable that can be reassigned", "A variable that cannot be reassigned", "A variable that is always a number", "A variable that is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a new line in C++ output?",
        options: ["\\n", "\\r", "endl", "Both A and C"],
        correctAnswer: 3,
      },
      {
        question: "What is the output of 'cout << \"Hello\" << \"World\";'?",
        options: ["HelloWorld", "Hello World", "Hello+World", "Error"],
        correctAnswer: 0,
      },
      {
        question: "Which operator is used for exponentiation?",
        options: ["^", "**", "pow()", "//"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'return' statement in a function?",
        options: ["To print a value", "To end the function", "To return a value from the function", "To define a variable"],
        correctAnswer: 2,
      },
      {
        question: "What is the correct syntax for a while loop?",
        options: ["while (condition)", "while (condition) {}", "while condition {}", "loop while condition"],
        correctAnswer: 1,
      },
      {
        question: "How do you check if a value is in a vector 'myVector'?",
        options: ["find(myVector.begin(), myVector.end(), value)", "myVector.includes('value')", "myVector.has('value')", "contains(myVector, value)"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'vector' in C++?",
        options: ["A dynamic array", "A fixed-size array", "A list of key-value pairs", "A type of class"],
        correctAnswer: 0,
      },
      {
        question: "Which header file is used for standard input/output operations?",
        options: ["<string>", "<vector>", "<iostream>", "<algorithm>"],
        correctAnswer: 2,
      },
      {
        question: "What is the difference between an 'int' and a 'float'?",
        options: ["'int' stores whole numbers, 'float' stores numbers with decimal points", "They are the same", "'int' is a keyword, 'float' is a class", "None of the above"],
        correctAnswer: 0,
      },
      {
        question: "How do you remove an element from a vector by its value?",
        options: ["myVector.remove(value)", "myVector.erase(value)", "myVector.erase(remove(myVector.begin(), myVector.end(), value), myVector.end())", "pop(myVector, value)"],
        correctAnswer: 2,
      },
      {
        question: "What is a 'reference' in C++?",
        options: ["A pointer to a variable", "An alias for a variable", "A global variable", "A type of class"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'cout << string(\"C++\").length();'?",
        options: ["3", "4", "2", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you convert a string to an integer?",
        options: ["stoi('10')", "str_to_int('10')", "to_int('10')", "integer('10')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is an immutable data type?",
        options: ["string", "array", "vector", "All are mutable"],
        correctAnswer: 3,
      },
      {
        question: "How do you open a file for writing in C++?",
        options: ["ofstream myFile('file.txt');", "ifstream myFile('file.txt');", "fstream myFile('file.txt');", "fopen('file.txt', 'w');"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'static' member variable in a class?",
        options: ["A member variable that is unique to each object", "A member variable that is shared by all objects of the class", "A constant variable", "A global variable"],
        correctAnswer: 1,
      },
      {
        question: "Which built-in function is used to get user input?",
        options: ["cin", "input()", "read()", "user_input()"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct way to create an empty vector of integers?",
        options: ["vector<int> myVector;", "vector myVector;", "int[] myVector;", "new vector<int>();"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'virtual' keyword?",
        options: ["To define a new type of variable", "To enable polymorphism in C++", "To handle errors", "To create a loop"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the size of a dynamically allocated array 'ptr'?",
        options: ["sizeof(ptr)", "ptr.size()", "You can't directly get the size", "size(ptr)"],
        correctAnswer: 2,
      },
      {
        question: "What is a 'namespace' in C++?",
        options: ["A single function", "A declarative region that provides a scope to the identifiers", "A file containing C++ code", "A variable"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'cout << 3 * 'A';'?",
        options: ["AAA", "3A", "195", "Error"],
        correctAnswer: 2,
      },
      {
        question: "Which data structure is used to implement a stack?",
        options: ["std::stack", "std::vector", "std::list", "All of the above"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'push_back()' method do on a vector?",
        options: ["Removes an item from the beginning of the vector", "Adds an item to the end of the vector", "Adds an item to the beginning of the vector", "Reverses the vector"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the type of a variable 'x'?",
        options: ["typeid(x).name()", "typeof(x)", "get_type(x)", "x.type()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'map' in C++?",
        options: ["An ordered collection of unique items", "An unordered collection of unique items", "A collection of key-value pairs", "An ordered collection of items"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'iomanip' header file?",
        options: ["To work with input/output manipulation", "To work with system-specific parameters and functions", "To handle files", "To work with dates and times"],
        correctAnswer: 0,
      },
      {
        question: "How do you sort a vector 'myVector'?",
        options: ["sort(myVector.begin(), myVector.end())", "myVector.sort()", "myVector.sorted()", "sort(myVector)"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'cout << 5 / 2;'?",
        options: ["2.5", "2", "3", "Error"],
        correctAnswer: 1,
      }
    ]
  },
  {
    category: "java",
    questions: [
      {
        question: "Which of the following is a correct way to declare an integer variable in Java?",
        options: ["var x = 10;", "int x = 10;", "let x = 10;", "x = 10;"],
        correctAnswer: 1,
      },
      {
        question: "How do you write a single-line comment in Java?",
        options: ["// This is a comment", "# this is a comment", "/* This is a comment */", "<!-- This is a comment -->"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'System.out.println(10 + 5);'?",
        options: ["10 + 5", "15", "105", "Error"],
        correctAnswer: 1,
      },
      {
        question: "Which keyword is used to define a class in Java?",
        options: ["class", "def", "func", "define"],
        correctAnswer: 0,
      },
      {
        question: "What is the file extension for a Java source file?",
        options: [".java", ".jav", ".jar", ".class"],
        correctAnswer: 0,
      },
      {
        question: "How do you create a new array of 5 integers in Java?",
        options: ["int[] arr = new int(5);", "int[] arr = new int[5];", "int[] arr = {5};", "int arr[5];"],
        correctAnswer: 1,
      },
      {
        question: "What is the correct way to get the length of an array named 'myArray'?",
        options: ["myArray.length()", "myArray.length", "len(myArray)", "myArray.size()"],
        correctAnswer: 1,
      },
      {
        question: "Which of the following is not a primitive data type in Java?",
        options: ["int", "boolean", "String", "double"],
        correctAnswer: 2,
      },
      {
        question: "How do you start a for loop in Java?",
        options: ["for (i = 0; i < 5; i++)", "for (int i = 0; i < 5; i++)", "for i in range(5)", "loop i from 0 to 5"],
        correctAnswer: 1,
      },
      {
        question: "What is the result of 'System.out.println(10 / 3);'?",
        options: ["3.333...", "3", "3.0", "Error"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'public static void main(String[] args)' method?",
        options: ["To define a class", "It is the entry point of the program", "To import packages", "To handle errors"],
        correctAnswer: 1,
      },
      {
        question: "How do you import a package named 'java.util'?",
        options: ["import 'java.util'", "import java.util.*;", "include java.util", "use java.util"],
        correctAnswer: 1,
      },
      {
        question: "What does the 'break' statement do in a loop?",
        options: ["It ends the program", "It exits the loop immediately", "It skips the current loop iteration", "It returns a value from a function"],
        correctAnswer: 1,
      },
      {
        question: "What is an 'object' in Java?",
        options: ["An ordered collection of items", "An instance of a class", "A list of numbers", "A type of comment"],
        correctAnswer: 1,
      },
      {
        question: "How do you access a public member 'name' from an object 'person'?",
        options: ["person.name", "person['name']", "Both A and B", "person('name')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is used to handle exceptions in Java?",
        options: ["try...catch", "try...except", "try...throw...catch", "error...handle"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'this' keyword?",
        options: ["It refers to the current method", "It refers to the current instance of the class", "It is a reserved keyword", "It is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a class named 'Car' in Java?",
        options: ["class Car {}", "define class Car {}", "create class Car {}", "class Car()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'final' variable?",
        options: ["A variable that can be reassigned", "A variable that cannot be reassigned", "A variable that is always a number", "A variable that is a global variable"],
        correctAnswer: 1,
      },
      {
        question: "How do you create a new line in Java output?",
        options: ["\\n", "\\r", "System.out.println()", "Both A and C"],
        correctAnswer: 3,
      },
      {
        question: "What is the output of 'System.out.print(\"Hello\" + \"World\");'?",
        options: ["HelloWorld", "Hello World", "Hello+World", "Error"],
        correctAnswer: 0,
      },
      {
        question: "Which operator is used for exponentiation?",
        options: ["^", "**", "Math.pow()", "//"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the 'return' statement in a function?",
        options: ["To print a value", "To end the method", "To return a value from the method", "To define a variable"],
        correctAnswer: 2,
      },
      {
        question: "What is the correct syntax for a while loop?",
        options: ["while (condition)", "while (condition) {}", "while condition {}", "loop while condition"],
        correctAnswer: 1,
      },
      {
        question: "How do you check if a value is in an array 'myArray'?",
        options: ["Arrays.asList(myArray).contains(value)", "myArray.includes(value)", "myArray.has(value)", "contains(myArray, value)"],
        correctAnswer: 0,
      },
      {
        question: "What is an 'interface' in Java?",
        options: ["A blueprint of a class", "A concrete class", "A class that contains only abstract methods", "A class with all private members"],
        correctAnswer: 0,
      },
      {
        question: "Which method is used to add an element to the end of an ArrayList?",
        options: ["add()", "push()", "append()", "insert()"],
        correctAnswer: 0,
      },
      {
        question: "What is the difference between '==' and '.equals()' for objects?",
        options: ["'==' checks for value equality, '.equals()' checks for reference equality", "'==' checks for reference equality, '.equals()' checks for value equality", "They are the same", "None of the above"],
        correctAnswer: 1,
      },
      {
        question: "How do you remove the last element from an ArrayList?",
        options: ["remove(size() - 1)", "pop()", "delete()", "splice()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'thread' in Java?",
        options: ["A new variable", "A single sequential flow of control within a program", "A type of class", "A way to handle errors"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'System.out.println(\"Java\".length());'?",
        options: ["4", "3", "5", "Error"],
        correctAnswer: 0,
      },
      {
        question: "How do you convert a string to an integer?",
        options: ["Integer.parseInt('10')", "str_to_int('10')", "to_int('10')", "integer('10')"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is a non-primitive data type?",
        options: ["char", "boolean", "double", "String"],
        correctAnswer: 3,
      },
      {
        question: "How do you get the current date and time?",
        options: ["new Date()", "getDate()", "currentDate()", "Date.now()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'static' member variable in a class?",
        options: ["A member variable that is unique to each object", "A member variable that is shared by all objects of the class", "A constant variable", "A global variable"],
        correctAnswer: 1,
      },
      {
        question: "Which built-in class is used to get user input?",
        options: ["Scanner", "Input", "Read", "Console"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct way to create an empty HashMap?",
        options: ["HashMap<String, String> map = new HashMap<>();", "HashMap map = new HashMap();", "Both A and B", "[]"],
        correctAnswer: 0,
      },
      {
        question: "What is the purpose of the 'extends' keyword?",
        options: ["To define a new type of variable", "To inherit from a class", "To handle errors", "To create a loop"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the first element of an ArrayList?",
        options: ["myList.get(0)", "myList.first()", "myList[0]", "myList.pop(0)"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'package' in Java?",
        options: ["A single function", "A way to group related classes and interfaces", "A file containing Java code", "A variable"],
        correctAnswer: 1,
      },
      {
        question: "What is the output of 'System.out.println(3 * 'A');'?",
        options: ["AAA", "3A", "65 * 3", "195"],
        correctAnswer: 3,
      },
      {
        question: "Which data structure is used to implement a stack?",
        options: ["Stack", "ArrayList", "LinkedList", "All of the above"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'trim()' method do on a String?",
        options: ["Removes all whitespace", "Removes leading and trailing whitespace", "Removes leading whitespace", "Removes trailing whitespace"],
        correctAnswer: 1,
      },
      {
        question: "How do you get the type of a variable 'x'?",
        options: ["x.getClass().getName()", "typeof(x)", "get_type(x)", "x.type()"],
        correctAnswer: 0,
      },
      {
        question: "What is a 'Set' in Java?",
        options: ["An ordered collection of unique items", "An unordered collection of unique items", "An ordered collection of items", "An unordered collection of items"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'java.io' package?",
        options: ["To work with input/output operations", "To work with system-specific parameters and functions", "To handle files", "To work with dates and times"],
        correctAnswer: 0,
      },
      {
        question: "How do you sort an ArrayList?",
        options: ["Collections.sort(myList)", "myList.sort()", "myList.sorted()", "sort(myList)"],
        correctAnswer: 0,
      },
      {
        question: "What is the output of 'System.out.println(5 % 2);'?",
        options: ["2.5", "2", "1", "Error"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of a 'constructor'?",
        options: ["To destroy an object", "To initialize a new object", "To define a method", "To handle exceptions"],
        correctAnswer: 1,
      }
    ]
  }
];
